<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>BCHAT APP - RESET PASSWORD</title>
</head>
<body>
    <h1>RESET PASSWORD URL: </h1>
    <a href="{{$url}}">reset password</a>
    <br/>
    <p>This link is valid for 1 hour<p/>
</body>
</html>